/* global React, ReactDOM */
const { useState, useEffect, useMemo, useRef, useCallback } = React;

// ─────────────────────────────────────────────────────────────────────────────
// MOCK DATA — models & their inputs (mirrors what the real backend serves)
// ─────────────────────────────────────────────────────────────────────────────

const MODELS = [
  {
    slug: 'black-forest-labs/flux-schnell',
    name: 'FLUX schnell',
    blurb: 'Fastest 4-step distilled FLUX',
    costPer: 0.003,
    inputs: [
      { name: 'prompt', type: 'string', default: 'A neon-lit ramen bar in Shibuya after midnight, steam curling under signage', sweepable: true },
      { name: 'aspect_ratio', type: 'enum', enum: ['1:1', '16:9', '9:16', '4:3', '3:4', '21:9'], default: '1:1', sweepable: true },
      { name: 'num_outputs', type: 'integer', default: 1, min: 1, max: 4, sweepable: false, description: 'Outputs per call (kept at 1 during sweeps).' },
      { name: 'num_inference_steps', type: 'integer', default: 4, min: 1, max: 4, sweepable: true, description: 'Schnell is distilled — fewer steps work best.' },
      { name: 'seed', type: 'integer', default: 1337, sweepable: true, description: 'Deterministic when fixed.' },
      { name: 'output_format', type: 'enum', enum: ['webp', 'png', 'jpg'], default: 'webp', sweepable: false },
    ],
  },
  {
    slug: 'black-forest-labs/flux-dev',
    name: 'FLUX dev',
    blurb: '12B param flagship — guidance-distilled',
    costPer: 0.025,
    inputs: [
      { name: 'prompt', type: 'string', default: 'Polaroid of an astronaut riding a bicycle through a forest of glass', sweepable: true },
      { name: 'aspect_ratio', type: 'enum', enum: ['1:1', '16:9', '9:16', '4:3', '3:4', '21:9'], default: '1:1', sweepable: true },
      { name: 'guidance', type: 'number', default: 3.5, min: 0, max: 10, sweepable: true, description: 'Higher = closer to prompt, lower = looser.' },
      { name: 'num_inference_steps', type: 'integer', default: 28, min: 1, max: 50, sweepable: true },
      { name: 'seed', type: 'integer', default: 1337, sweepable: true },
      { name: 'output_format', type: 'enum', enum: ['webp', 'png', 'jpg'], default: 'webp', sweepable: false },
    ],
  },
  {
    slug: 'stability-ai/sdxl',
    name: 'SDXL',
    blurb: 'Stable Diffusion XL — broad style range',
    costPer: 0.012,
    inputs: [
      { name: 'prompt', type: 'string', default: 'A windswept lighthouse on a cliff, oil on canvas, dramatic chiaroscuro', sweepable: true },
      { name: 'negative_prompt', type: 'string', default: 'blurry, watermark, low quality', sweepable: false },
      { name: 'width', type: 'integer', enum: [512, 768, 1024, 1152, 1344], default: 1024, sweepable: true },
      { name: 'height', type: 'integer', enum: [512, 768, 1024, 1152, 1344], default: 1024, sweepable: true },
      { name: 'guidance_scale', type: 'number', default: 7.5, min: 1, max: 20, sweepable: true },
      { name: 'num_inference_steps', type: 'integer', default: 30, min: 1, max: 50, sweepable: true },
      { name: 'scheduler', type: 'enum', enum: ['DDIM', 'DPMSolverMultistep', 'K_EULER', 'K_EULER_ANCESTRAL', 'PNDM'], default: 'K_EULER', sweepable: true },
      { name: 'seed', type: 'integer', default: 42, sweepable: true },
    ],
  },
  {
    slug: 'ideogram-ai/ideogram-v2',
    name: 'Ideogram v2',
    blurb: 'Best-in-class text rendering',
    costPer: 0.08,
    inputs: [
      { name: 'prompt', type: 'string', default: 'Magazine cover, headline "QUIET ENGINES", soft duotone illustration', sweepable: true },
      { name: 'aspect_ratio', type: 'enum', enum: ['1:1', '16:9', '9:16', '4:3', '3:4', '16:10'], default: '1:1', sweepable: true },
      { name: 'style_type', type: 'enum', enum: ['Auto', 'General', 'Realistic', 'Design', 'Render 3D', 'Anime'], default: 'Auto', sweepable: true },
      { name: 'magic_prompt_option', type: 'enum', enum: ['Auto', 'On', 'Off'], default: 'Auto', sweepable: true },
      { name: 'seed', type: 'integer', default: 7, sweepable: true },
    ],
  },
  {
    slug: 'recraft-ai/recraft-v3',
    name: 'Recraft v3',
    blurb: 'Vector + raster, brand-grade output',
    costPer: 0.04,
    inputs: [
      { name: 'prompt', type: 'string', default: 'Minimal product still life of a brass kettle on cream linen', sweepable: true },
      { name: 'size', type: 'enum', enum: ['1024x1024', '1365x1024', '1024x1365', '1536x1024', '2048x1024'], default: '1024x1024', sweepable: true },
      { name: 'style', type: 'enum', enum: ['any', 'realistic_image', 'digital_illustration', 'vector_illustration', 'icon'], default: 'realistic_image', sweepable: true },
    ],
  },
];

const PROMPT_DIRECTIONS = [
  'subject_variation',
  'style_variation',
  'lighting_variation',
  'composition_variation',
  'palette_variation',
  'time_of_day',
  'camera_angle',
  'medium_variation',
];

// Pre-baked plausible expansions keyed by direction (mocking the LLM expander)
const EXPANSION_SEEDS = {
  subject_variation: [
    (b) => b.replace(/^A /, 'A ramen master plating ').replace(/\bramen\b/, 'tonkotsu'),
    (b) => b.replace(/ramen bar/, 'soba counter').replace('Shibuya', 'Shimokitazawa'),
    (b) => b.replace(/A /, 'A pair of regulars at a '),
    (b) => b.replace('after midnight', 'as the last train passes'),
    (b) => b.replace(/A /, 'A solitary chef behind a '),
  ],
  style_variation: [
    (b) => `${b}, in the style of Wong Kar-wai`,
    (b) => `${b}, watercolor concept art, soft washes`,
    (b) => `${b}, 35mm film, halation around the highlights`,
    (b) => `${b}, hyper-detailed digital painting, sharp linework`,
    (b) => `${b}, low-poly cinematic render`,
  ],
  lighting_variation: [
    (b) => `${b}, warm tungsten dominates`,
    (b) => `${b}, single sodium lamp overhead`,
    (b) => `${b}, neon throw — cyan key, magenta fill`,
    (b) => `${b}, predawn ambient, no signage lit`,
    (b) => `${b}, candlelit only`,
  ],
  composition_variation: [
    (b) => `${b}, shot from across the street, deep zoom`,
    (b) => `${b}, tight over-the-shoulder of a patron`,
    (b) => `${b}, top-down counter view, flatlay`,
    (b) => `${b}, dutch angle, off-kilter framing`,
    (b) => `${b}, symmetrical centered hero shot`,
  ],
  palette_variation: [
    (b) => `${b}, muted earth tones`,
    (b) => `${b}, vivid jewel-tone palette`,
    (b) => `${b}, monochrome sepia`,
    (b) => `${b}, cool blue + soft amber duotone`,
    (b) => `${b}, washed pastel palette`,
  ],
  time_of_day: [
    (b) => `${b}, golden hour spilling in`,
    (b) => `${b}, the blue hour just after sunset`,
    (b) => `${b}, dead of night, signage off`,
    (b) => `${b}, first light of morning`,
    (b) => `${b}, overcast noon`,
  ],
  camera_angle: [
    (b) => `${b}, low angle, ant's-eye view`,
    (b) => `${b}, isometric three-quarter`,
    (b) => `${b}, drone overhead`,
    (b) => `${b}, eye-level handheld`,
    (b) => `${b}, extreme close-up macro`,
  ],
  medium_variation: [
    (b) => `${b}, rendered in oil paint`,
    (b) => `${b}, as a charcoal sketch`,
    (b) => `${b}, as a risograph print, 2-color`,
    (b) => `${b}, as a stop-motion clay set`,
    (b) => `${b}, as a Polaroid SX-70 instant`,
  ],
};

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function parseSweepValues(text, type) {
  return text
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => {
      if (type === 'integer') return parseInt(s, 10);
      if (type === 'number') return parseFloat(s);
      return s;
    })
    .filter((v) => !(typeof v === 'number' && Number.isNaN(v)));
}

function fmtVal(v) {
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(2);
  if (typeof v === 'string' && v.length > 28) return `"${v.slice(0, 26)}…"`;
  return String(v);
}

function pickImage(seed) {
  // Deterministic, recognizable but varied placeholders
  const ids = [1015, 1025, 1043, 1059, 1062, 1074, 1080, 119, 250, 326, 376, 433, 535, 645, 718, 823, 877, 901, 957, 1011, 1018, 1027, 1033];
  const i = Math.abs(hash(String(seed))) % ids.length;
  return `https://picsum.photos/id/${ids[i]}/640/640`;
}

function hash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}

function classNames(...xs) { return xs.filter(Boolean).join(' '); }

// ─────────────────────────────────────────────────────────────────────────────
// Main App
// ─────────────────────────────────────────────────────────────────────────────

function App() {
  const { useTweaks, TweaksPanel, TweakSection, TweakColor, TweakRadio, TweakToggle } = window;

  const [t, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "accent": "#e8b96b",
    "theme": "dark",
    "density": "comfortable",
    "frameStyle": "label"
  }/*EDITMODE-END*/);

  // Apply theme + accent vars
  useEffect(() => {
    document.body.classList.toggle('theme-light', t.theme === 'light');
    // density
    document.documentElement.style.setProperty('--cell-radius', t.frameStyle === 'film' ? '0px' : '3px');
  }, [t.theme, t.frameStyle]);

  useEffect(() => {
    // Set accent via CSS vars
    const root = document.documentElement;
    root.style.setProperty('--accent', t.accent);
    // Compute soft variant
    root.style.setProperty('--accent-soft', t.accent + '22');
  }, [t.accent]);

  const [modelSlug, setModelSlug] = useState(MODELS[0].slug);
  const model = MODELS.find((m) => m.slug === modelSlug);
  const [modelOpen, setModelOpen] = useState(false);

  // Per-input state: { mode: 'fixed' | 'sweep', value: any, sweepValue: any }
  const [inputState, setInputState] = useState({});
  // re-init when model changes
  useEffect(() => {
    const init = {};
    for (const inp of model.inputs) {
      init[inp.name] = {
        mode: 'fixed',
        value: inp.default ?? '',
        sweepValue: inp.type === 'enum' ? [] : '',
        promptVariations: [],
        promptDirection: 'style_variation',
        promptCount: 5,
      };
    }
    setInputState(init);
  }, [modelSlug]);

  const [runs, setRuns] = useState([]); // array of { id, params, cells: [{id, label, status, url, ms}] }
  const [activeRunId, setActiveRunId] = useState(null);
  const activeRun = runs.find((r) => r.id === activeRunId) || null;

  // ── compute cost preview / sweep size ──
  const sweepMatrix = useMemo(() => {
    if (!model) return { combos: [[{}]], axes: [], count: 1 };
    const axes = [];
    for (const inp of model.inputs) {
      const st = inputState[inp.name];
      if (!st || st.mode !== 'sweep') continue;
      let values = [];
      if (inp.name === 'prompt') values = st.promptVariations.filter(Boolean);
      else if (Array.isArray(st.sweepValue)) values = st.sweepValue;
      else if (typeof st.sweepValue === 'string') values = parseSweepValues(st.sweepValue, inp.type);
      if (values.length) axes.push({ name: inp.name, values });
    }
    let combos = [[{}]];
    for (const ax of axes) {
      const next = [];
      for (const c of combos) {
        for (const v of ax.values) {
          next.push([...c.slice(0, -1), { ...c[c.length - 1], [ax.name]: v }]);
        }
      }
      combos = next.map((c) => [c[c.length - 1]]);
    }
    const flat = combos.map((c) => c[0]);
    return { combos: flat, axes, count: Math.min(flat.length, 9), truncated: flat.length > 9 };
  }, [model, inputState]);

  const totalCost = (sweepMatrix.count || 1) * (model?.costPer || 0);

  // ── handlers ──
  const update = (name, patch) =>
    setInputState((s) => ({ ...s, [name]: { ...(s[name] || {}), ...patch } }));

  const handlePromptExpand = (name) => {
    const st = inputState[name];
    const base = st.value;
    const seeds = EXPANSION_SEEDS[st.promptDirection] || EXPANSION_SEEDS.style_variation;
    const variations = [];
    for (let i = 0; i < st.promptCount; i++) {
      const fn = seeds[i % seeds.length];
      try { variations.push(fn(base)); } catch { variations.push(base); }
    }
    update(name, { promptVariations: variations });
  };

  const handleRun = () => {
    const combos = sweepMatrix.combos.slice(0, 9);
    const fixedParams = {};
    for (const inp of model.inputs) {
      const st = inputState[inp.name];
      if (st && st.mode === 'fixed') fixedParams[inp.name] = st.value;
    }
    const id = `run-${Date.now()}`;
    const cells = combos.map((overrides, i) => {
      const params = { ...fixedParams, ...overrides };
      const labelBits = Object.entries(overrides).map(([k, v]) => `${k}=${fmtVal(v)}`);
      return {
        id: `${id}-${i}`,
        index: i + 1,
        label: labelBits.join(' · ') || 'baseline',
        params,
        status: 'queued',
        url: null,
        ms: null,
        startedAt: Date.now() + i * 80,
      };
    });
    const run = {
      id,
      slug: modelSlug,
      startedAt: Date.now(),
      cells,
      total: combos.length,
      truncated: sweepMatrix.truncated,
      axes: sweepMatrix.axes.map((a) => a.name),
    };
    setRuns((rs) => [run, ...rs].slice(0, 8));
    setActiveRunId(id);

    // Simulate generation cell-by-cell
    cells.forEach((cell, i) => {
      const startDelay = 200 + i * 220;
      const genDuration = 1400 + Math.random() * 2200;
      setTimeout(() => {
        setRuns((rs) => rs.map((r) => r.id !== id ? r : {
          ...r,
          cells: r.cells.map((c) => c.id === cell.id ? { ...c, status: 'running', startedAt: Date.now() } : c),
        }));
      }, startDelay);
      setTimeout(() => {
        const failed = Math.random() < 0.06;
        setRuns((rs) => rs.map((r) => r.id !== id ? r : {
          ...r,
          cells: r.cells.map((c) => c.id === cell.id ? {
            ...c,
            status: failed ? 'failed' : 'complete',
            url: failed ? null : pickImage(cell.id + (inputState.seed?.value || 0)),
            ms: Math.round(genDuration),
            error: failed ? 'NSFW filter triggered' : null,
          } : c),
        }));
      }, startDelay + genDuration);
    });
  };

  const runStatus = activeRun ? (
    activeRun.cells.every((c) => c.status === 'complete' || c.status === 'failed') ? 'done' :
    activeRun.cells.some((c) => c.status === 'running' || c.status === 'queued') ? 'running' : 'idle'
  ) : 'idle';

  const completedCount = activeRun?.cells.filter((c) => c.status === 'complete').length || 0;
  const totalMs = activeRun?.cells.reduce((s, c) => s + (c.ms || 0), 0) || 0;
  const isRunning = runStatus === 'running';

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '232px 1fr', minHeight: '100vh' }}>
      {/* ─── Sidebar ─── */}
      <Sidebar runs={runs} activeRunId={activeRunId} setActiveRunId={setActiveRunId} models={MODELS} modelSlug={modelSlug} setModelSlug={setModelSlug} />

      {/* ─── Main column ─── */}
      <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <TopBar
          model={model}
          modelOpen={modelOpen}
          setModelOpen={setModelOpen}
          onSelectModel={(slug) => { setModelSlug(slug); setModelOpen(false); }}
          sweepCount={sweepMatrix.count}
          totalCost={totalCost}
          truncated={sweepMatrix.truncated}
          runStatus={runStatus}
          completed={completedCount}
          total={activeRun?.total || 0}
          onRun={handleRun}
          isRunning={isRunning}
          sweepAxes={sweepMatrix.axes}
        />

        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(360px, 420px) 1fr', minHeight: 0, flex: 1 }}>
          {/* ─── Form pane ─── */}
          <FormPane
            model={model}
            inputState={inputState}
            update={update}
            onExpand={handlePromptExpand}
          />

          {/* ─── Results pane ─── */}
          <ResultsPane
            activeRun={activeRun}
            frameStyle={t.frameStyle}
            density={t.density}
          />
        </div>
      </div>

      {/* ─── Tweaks Panel ─── */}
      <TweaksPanel>
        <TweakSection label="Accent">
          <TweakColor
            label="Color"
            value={t.accent}
            onChange={(v) => setTweak('accent', v)}
            options={[
              '#e8b96b', /* amber phosphor */
              '#a8d96c', /* lime CRT */
              '#7ab9ff', /* cobalt */
              '#e87a99', /* hot pink */
              '#d4d2cb'  /* paper */
            ]}
          />
        </TweakSection>
        <TweakSection label="Theme">
          <TweakRadio
            label="Mode"
            value={t.theme}
            onChange={(v) => setTweak('theme', v)}
            options={[{ value: 'dark', label: 'Dark' }, { value: 'light', label: 'Light' }]}
          />
        </TweakSection>
        <TweakSection label="Contact sheet">
          <TweakRadio
            label="Frame"
            value={t.frameStyle}
            onChange={(v) => setTweak('frameStyle', v)}
            options={[
              { value: 'label', label: 'Label' },
              { value: 'film', label: 'Film' },
            ]}
          />
          <TweakRadio
            label="Density"
            value={t.density}
            onChange={(v) => setTweak('density', v)}
            options={[
              { value: 'comfortable', label: 'Comfortable' },
              { value: 'compact', label: 'Compact' },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Sidebar
// ─────────────────────────────────────────────────────────────────────────────

function Sidebar({ runs, activeRunId, setActiveRunId, models, modelSlug, setModelSlug }) {
  return (
    <aside className="sidebar" style={{ display: 'flex', flexDirection: 'column', height: '100vh', position: 'sticky', top: 0 }}>
      {/* Wordmark */}
      <div style={{ padding: '20px 22px 18px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <SweepMark />
        <div>
          <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: '-0.02em' }}>Sweep</div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', letterSpacing: '0.06em' }}>v0.4 · local</div>
        </div>
      </div>
      <div className="rule" />

      {/* Quick model nav */}
      <div style={{ padding: '14px 14px 6px' }}>
        <div className="label-mono" style={{ marginBottom: 8, padding: '0 8px' }}>Models</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {models.map((m) => (
            <div
              key={m.slug}
              className={classNames('nav-item', m.slug === modelSlug && 'active')}
              onClick={() => setModelSlug(m.slug)}
            >
              <span className="nav-icon" />
              <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.name}</span>
              <span className="mono" style={{ fontSize: 10, color: 'var(--ink-4)' }}>${m.costPer.toFixed(3)}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="rule" style={{ margin: '14px 0' }} />

      {/* Run history */}
      <div style={{ padding: '0 14px', flex: 1, overflow: 'auto', minHeight: 0 }}>
        <div className="label-mono" style={{ marginBottom: 8, padding: '0 8px' }}>Recent sweeps</div>
        {runs.length === 0 && (
          <div style={{ padding: '12px 8px', fontSize: 12, color: 'var(--ink-4)', lineHeight: 1.5 }}>
            No sweeps yet. Configure parameters and press Run.
          </div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {runs.map((r) => {
            const done = r.cells.filter((c) => c.status === 'complete' || c.status === 'failed').length;
            return (
              <div
                key={r.id}
                className={classNames('nav-item', r.id === activeRunId && 'active')}
                onClick={() => setActiveRunId(r.id)}
                style={{ alignItems: 'flex-start', padding: '8px 10px' }}
              >
                <span className="nav-icon" style={{ marginTop: 5 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, color: 'var(--ink)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {r.axes.length ? r.axes.join(' × ') : 'baseline'}
                  </div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', marginTop: 2 }}>
                    {done}/{r.total} · {timeAgo(r.startedAt)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer */}
      <div className="rule" />
      <div style={{ padding: '14px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span className="status-pill"><span className="pulse" />Replicate · connected</span>
        <span className="mono" style={{ fontSize: 10, color: 'var(--ink-4)' }}>⌘K</span>
      </div>
    </aside>
  );
}

function timeAgo(ts) {
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}

function SweepMark() {
  return (
    <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
      <rect x="0.5" y="0.5" width="25" height="25" rx="3" stroke="var(--border-strong)" />
      <path d="M5 17 Q9 6, 13 13 T21 9" stroke="var(--accent)" strokeWidth="1.5" fill="none" strokeLinecap="round" />
      <circle cx="5" cy="17" r="1.5" fill="var(--accent)" />
      <circle cx="21" cy="9" r="1.5" fill="var(--accent)" />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Top bar
// ─────────────────────────────────────────────────────────────────────────────

function TopBar({ model, modelOpen, setModelOpen, onSelectModel, sweepCount, totalCost, truncated, runStatus, completed, total, onRun, isRunning, sweepAxes }) {
  return (
    <div style={{ borderBottom: '1px solid var(--border)', background: 'var(--bg)', position: 'sticky', top: 0, zIndex: 5 }}>
      <div style={{ display: 'flex', alignItems: 'center', padding: '14px 28px', gap: 24, minHeight: 64 }}>
        {/* Title + model picker */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, minWidth: 0 }}>
          <div>
            <div style={{ fontSize: 17, fontWeight: 600, letterSpacing: '-0.02em' }}>
              Parameter sweep
            </div>
            <div className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)', letterSpacing: '0.06em', marginTop: 2 }}>
              {model.slug.toUpperCase()}
            </div>
          </div>
        </div>

        <div style={{ flex: 1 }} />

        {/* Sweep summary */}
        <div className="cost-readout">
          <span>axes</span>
          <span className="v">{sweepAxes.length}</span>
          <span className="sep">/</span>
          <span>cells</span>
          <span className="v">{sweepCount}{truncated && <span style={{ color: 'var(--ink-4)' }}>·max9</span>}</span>
          <span className="sep">/</span>
          <span>est</span>
          <span className="v">${totalCost.toFixed(3)}</span>
        </div>

        {/* Run button */}
        <button className="btn btn-primary" onClick={onRun} disabled={isRunning}>
          {isRunning ? (
            <>
              <span className="spinner" style={{ width: 12, height: 12, borderTopColor: 'var(--accent-ink)', borderColor: 'rgba(0,0,0,0.25)', borderTopWidth: 1.5 }} />
              <span>Running {completed}/{total}</span>
            </>
          ) : (
            <>
              <PlayIcon />
              <span>Run sweep</span>
              <span className="mono" style={{ opacity: 0.7, fontSize: 11, marginLeft: 2 }}>⏎</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}

function PlayIcon() {
  return (
    <svg width="9" height="11" viewBox="0 0 9 11" fill="currentColor">
      <path d="M0 0v11l9-5.5L0 0z" />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Form pane
// ─────────────────────────────────────────────────────────────────────────────

function FormPane({ model, inputState, update, onExpand }) {
  return (
    <div style={{ borderRight: '1px solid var(--border)', padding: '24px 26px 64px', overflow: 'auto', maxHeight: 'calc(100vh - 64px)' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 4 }}>
        <h2 style={{ fontSize: 14, fontWeight: 600, margin: 0, letterSpacing: '-0.01em' }}>Inputs</h2>
        <span className="label-mono">{model.inputs.length} fields</span>
      </div>
      <p style={{ fontSize: 12.5, color: 'var(--ink-3)', margin: '6px 0 22px', lineHeight: 1.5 }}>
        {model.blurb}. Toggle any sweepable field to <span style={{ color: 'var(--accent)' }}>sweep</span> to vary it across cells.
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        {model.inputs.map((inp) => (
          <InputField
            key={inp.name}
            input={inp}
            state={inputState[inp.name]}
            update={(p) => update(inp.name, p)}
            onExpand={() => onExpand(inp.name)}
          />
        ))}
      </div>
    </div>
  );
}

function InputField({ input, state, update, onExpand }) {
  if (!state) return null;
  const isSweep = state.mode === 'sweep';
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 7 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <span style={{ fontSize: 12.5, fontWeight: 500 }} className="mono">
            {input.name}
          </span>
          <span className="mono" style={{ fontSize: 10, color: 'var(--ink-4)', letterSpacing: '0.04em' }}>
            {input.type}{input.enum ? `<${input.enum.length}>` : ''}
          </span>
        </div>
        {input.sweepable && (
          <div className="seg">
            <button className={classNames(!isSweep && 'is-on')} onClick={() => update({ mode: 'fixed' })}>Fixed</button>
            <button className={classNames(isSweep && 'is-on is-accent')} onClick={() => update({ mode: 'sweep' })}>Sweep</button>
          </div>
        )}
      </div>

      {!isSweep ? <FixedControl input={input} state={state} update={update} /> : <SweepControl input={input} state={state} update={update} onExpand={onExpand} />}

      {input.description && (
        <p style={{ fontSize: 11.5, color: 'var(--ink-4)', margin: '7px 0 0', lineHeight: 1.4 }}>{input.description}</p>
      )}
    </div>
  );
}

function FixedControl({ input, state, update }) {
  const onChange = (v) => update({ value: v });
  if (input.enum) {
    return (
      <select className="field" value={state.value} onChange={(e) => onChange(input.type === 'integer' ? parseInt(e.target.value, 10) : input.type === 'number' ? parseFloat(e.target.value) : e.target.value)}>
        {input.enum.map((v) => <option key={v} value={v}>{v}</option>)}
      </select>
    );
  }
  if (input.type === 'number' || input.type === 'integer') {
    const hasRange = input.minimum !== undefined || input.min !== undefined;
    const min = input.minimum ?? input.min;
    const max = input.maximum ?? input.max;
    if (hasRange && max !== undefined) {
      return (
        <div className="range-row">
          <input
            type="range"
            className="range-control"
            min={min}
            max={max}
            step={input.type === 'integer' ? 1 : 0.1}
            value={state.value}
            onChange={(e) => onChange(input.type === 'integer' ? parseInt(e.target.value, 10) : parseFloat(e.target.value))}
          />
          <span className="num-chip">{fmtVal(state.value)}</span>
        </div>
      );
    }
    return (
      <input type="number" className="field mono" value={state.value}
        onChange={(e) => onChange(input.type === 'integer' ? parseInt(e.target.value, 10) : parseFloat(e.target.value))} />
    );
  }
  if (input.name === 'prompt' || (typeof state.value === 'string' && state.value.length > 60)) {
    return (
      <textarea className="field" rows={3} value={state.value} onChange={(e) => onChange(e.target.value)} />
    );
  }
  return (
    <input type="text" className="field" value={state.value} onChange={(e) => onChange(e.target.value)} />
  );
}

function SweepControl({ input, state, update, onExpand }) {
  if (input.name === 'prompt') {
    return <PromptSweepControl state={state} update={update} onExpand={onExpand} />;
  }
  if (input.enum) {
    const selected = state.sweepValue || [];
    const toggle = (v) => {
      const next = selected.includes(v) ? selected.filter((x) => x !== v) : [...selected, v];
      update({ sweepValue: next });
    };
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {input.enum.map((v) => (
          <button key={v} className={classNames('chip', selected.includes(v) && 'is-on')} onClick={() => toggle(v)} type="button">
            <span className="dot" />
            {v}
          </button>
        ))}
      </div>
    );
  }
  // Numeric / text sweep input with example helper
  const placeholder = input.type === 'integer' ? 'e.g. 1, 4, 8, 16' : input.type === 'number' ? 'e.g. 1.0, 3.5, 7.0' : 'comma-separated values';
  return (
    <div>
      <input
        type="text"
        className="field mono"
        placeholder={placeholder}
        value={state.sweepValue || ''}
        onChange={(e) => update({ sweepValue: e.target.value })}
      />
      {typeof state.sweepValue === 'string' && state.sweepValue.trim() && (
        <div style={{ marginTop: 6, display: 'flex', flexWrap: 'wrap', gap: 5 }}>
          {parseSweepValues(state.sweepValue, input.type).map((v, i) => (
            <span key={i} className="mono" style={{ fontSize: 10.5, color: 'var(--accent)', background: 'var(--accent-soft)', padding: '2px 7px', borderRadius: 3 }}>
              {fmtVal(v)}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function PromptSweepControl({ state, update, onExpand }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', border: '1px solid var(--border)', borderRadius: 4, background: 'var(--surface)' }}>
        <span className="label-mono" style={{ flexShrink: 0 }}>Base</span>
        <span style={{ fontSize: 12, color: 'var(--ink-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontStyle: 'italic' }}>
          {state.value}
        </span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 70px auto', gap: 6 }}>
        <select className="field mono" style={{ fontSize: 12 }} value={state.promptDirection} onChange={(e) => update({ promptDirection: e.target.value })}>
          {PROMPT_DIRECTIONS.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select className="field mono" style={{ fontSize: 12 }} value={state.promptCount} onChange={(e) => update({ promptCount: parseInt(e.target.value, 10) })}>
          {[3, 5, 7, 9].map((n) => <option key={n} value={n}>{n}</option>)}
        </select>
        <button className="btn" onClick={onExpand} style={{ padding: '7px 12px', fontSize: 12 }}>
          <SparkIcon />
          Expand
        </button>
      </div>
      {state.promptVariations.length > 0 && (
        <div className="fade-up" style={{ borderTop: '1px dashed var(--border)', paddingTop: 6 }}>
          <div className="label-mono" style={{ margin: '6px 0' }}>{state.promptVariations.length} variations</div>
          {state.promptVariations.map((v, i) => (
            <div key={i} className="var-row">
              <div className="var-num">{String(i + 1).padStart(2, '0')}</div>
              <textarea
                className="field"
                rows={2}
                value={v}
                onChange={(e) => {
                  const next = [...state.promptVariations];
                  next[i] = e.target.value;
                  update({ promptVariations: next });
                }}
                style={{ fontSize: 12.5 }}
              />
              <button
                className="btn-ghost btn"
                style={{ padding: '4px 6px', alignSelf: 'flex-start', marginTop: 4 }}
                onClick={() => update({ promptVariations: state.promptVariations.filter((_, j) => j !== i) })}
              >
                <XIcon />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SparkIcon() {
  return (
    <svg width="10" height="11" viewBox="0 0 10 11" fill="none" stroke="currentColor" strokeWidth="1.2">
      <path d="M5 0v4M5 7v4M0 5.5h4M6 5.5h4" strokeLinecap="round" />
    </svg>
  );
}
function XIcon() {
  return (
    <svg width="10" height="10" viewBox="0 0 10 10" stroke="currentColor" strokeWidth="1.2"><path d="M1 1l8 8M9 1l-8 8" strokeLinecap="round" /></svg>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Results pane (contact-sheet)
// ─────────────────────────────────────────────────────────────────────────────

function ResultsPane({ activeRun, frameStyle, density }) {
  const [tab, setTab] = useState('grid');

  if (!activeRun) {
    return <EmptyResults />;
  }

  const total = activeRun.cells.length;
  const cols = total <= 1 ? 1 : total <= 4 ? 2 : 3;
  const completed = activeRun.cells.filter((c) => c.status === 'complete').length;
  const failed = activeRun.cells.filter((c) => c.status === 'failed').length;

  return (
    <div style={{ padding: '20px 28px 64px', overflow: 'auto', maxHeight: 'calc(100vh - 64px)' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 14 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
            <h2 style={{ fontSize: 14, fontWeight: 600, margin: 0, letterSpacing: '-0.01em' }}>Sheet</h2>
            <span className="label-mono">{activeRun.axes.length ? activeRun.axes.join(' × ') : 'baseline'}</span>
          </div>
          <div style={{ display: 'flex', gap: 16, marginTop: 8 }}>
            <span className="cost-readout"><span>frames</span><span className="v">{completed}/{total}</span></span>
            {failed > 0 && <span className="cost-readout"><span>failed</span><span className="v" style={{ color: 'var(--danger)' }}>{failed}</span></span>}
            <span className="cost-readout"><span>started</span><span className="v">{timeAgo(activeRun.startedAt)}</span></span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-ghost" style={{ fontSize: 12, padding: '6px 10px' }}>
            <DownloadIcon />Download .zip
          </button>
          <button className="btn btn-ghost" style={{ fontSize: 12, padding: '6px 10px' }}>
            <ShareIcon />Share
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1px solid var(--border)', marginBottom: 20 }}>
        <div className={classNames('tab', tab === 'grid' && 'is-active')} onClick={() => setTab('grid')}>Contact sheet</div>
        <div className={classNames('tab', tab === 'params' && 'is-active')} onClick={() => setTab('params')}>Parameters <span className="count">{Object.keys(activeRun.cells[0]?.params || {}).length}</span></div>
        <div className={classNames('tab', tab === 'json' && 'is-active')} onClick={() => setTab('json')}>JSON</div>
      </div>

      {/* Progress bar */}
      {completed + failed < total && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ height: 2, background: 'var(--border)', borderRadius: 999, overflow: 'hidden', position: 'relative' }}>
            <div style={{ height: '100%', width: `${((completed + failed) / total) * 100}%`, background: 'var(--accent)', transition: 'width 300ms ease' }} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
            <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>
              {completed + failed}/{total} cells settled
            </span>
            <span className="mono" style={{ fontSize: 10.5, color: 'var(--accent)' }}>
              ●  generating
            </span>
          </div>
        </div>
      )}

      {activeRun.truncated && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--ink-3)', background: 'var(--surface)', border: '1px solid var(--border)', padding: '8px 12px', borderRadius: 4, marginBottom: 14 }}>
          <InfoIcon />
          Sweep truncated to 9 cells. Reduce axes or value count to see the full matrix.
        </div>
      )}

      {tab === 'grid' && (
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: density === 'compact' ? 8 : 14 }}>
          {activeRun.cells.map((cell, i) => (
            <Cell key={cell.id} cell={cell} frameStyle={frameStyle} index={i + 1} total={total} />
          ))}
        </div>
      )}
      {tab === 'params' && <ParamsTable run={activeRun} />}
      {tab === 'json' && <JsonView run={activeRun} />}
    </div>
  );
}

function Cell({ cell, frameStyle, index, total }) {
  const isComplete = cell.status === 'complete';
  const isFailed = cell.status === 'failed';
  const isRunning = cell.status === 'running';
  const isQueued = cell.status === 'queued';

  return (
    <div className={classNames('frame', frameStyle === 'film' && 'frame-corners')} style={{ aspectRatio: '1 / 1' }}>
      {frameStyle === 'film' && <span className="corner-bl"></span>}
      {frameStyle === 'film' && <span className="corner-br"></span>}
      {cell.label && (
        <div className="frame-label">{cell.label}</div>
      )}
      <div className="frame-index">{String(index).padStart(2, '0')}/{String(total).padStart(2, '0')}</div>

      {isComplete && (
        <img
          src={cell.url}
          alt={cell.label}
          className="fade-up"
          style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
          loading="lazy"
        />
      )}

      {(isQueued || isRunning) && (
        <div className="stripes" style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
          {isRunning ? <div className="spinner" /> : <div style={{ width: 6, height: 6, borderRadius: 999, background: 'var(--ink-4)' }} />}
          <span className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
            {isRunning ? 'generating' : 'queued'}
          </span>
        </div>
      )}

      {isFailed && (
        <div style={{ background: 'var(--surface)', width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 16, textAlign: 'center' }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--danger)" strokeWidth="1.4">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 8v5M12 16v.5" strokeLinecap="round" />
          </svg>
          <span className="mono" style={{ fontSize: 11, color: 'var(--danger)' }}>failed</span>
          <span style={{ fontSize: 11, color: 'var(--ink-3)' }}>{cell.error}</span>
        </div>
      )}

      {isComplete && (
        <div style={{ position: 'absolute', bottom: 8, left: 10, zIndex: 2 }} className="mono">
          <span style={{ fontSize: 10, color: 'var(--ink)', background: 'rgba(13, 12, 11, 0.7)', backdropFilter: 'blur(4px)', padding: '3px 6px', borderRadius: 2 }}>
            {(cell.ms / 1000).toFixed(1)}s
          </span>
        </div>
      )}
    </div>
  );
}

function ParamsTable({ run }) {
  const keys = Array.from(new Set(run.cells.flatMap((c) => Object.keys(c.params))));
  return (
    <div style={{ border: '1px solid var(--border)', borderRadius: 4, overflow: 'hidden' }}>
      <table className="mono" style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11.5 }}>
        <thead>
          <tr style={{ background: 'var(--surface)' }}>
            <th style={{ textAlign: 'left', padding: '8px 10px', color: 'var(--ink-3)', fontWeight: 500, borderBottom: '1px solid var(--border)' }}>#</th>
            {keys.map((k) => (
              <th key={k} style={{ textAlign: 'left', padding: '8px 10px', color: 'var(--ink-3)', fontWeight: 500, borderBottom: '1px solid var(--border)' }}>{k}</th>
            ))}
            <th style={{ textAlign: 'right', padding: '8px 10px', color: 'var(--ink-3)', fontWeight: 500, borderBottom: '1px solid var(--border)' }}>ms</th>
          </tr>
        </thead>
        <tbody>
          {run.cells.map((c, i) => (
            <tr key={c.id} style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '7px 10px', color: 'var(--ink-4)' }}>{String(i + 1).padStart(2, '0')}</td>
              {keys.map((k) => (
                <td key={k} style={{ padding: '7px 10px', color: 'var(--ink-2)', maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {fmtVal(c.params[k])}
                </td>
              ))}
              <td style={{ padding: '7px 10px', textAlign: 'right', color: c.status === 'complete' ? 'var(--ink)' : 'var(--ink-4)' }}>
                {c.ms ? c.ms : '—'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function JsonView({ run }) {
  const text = JSON.stringify({ slug: run.slug, cells: run.cells.map((c) => ({ params: c.params, status: c.status, ms: c.ms, output_url: c.url, error: c.error })) }, null, 2);
  return (
    <pre className="mono" style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 4, padding: 16, fontSize: 11.5, lineHeight: 1.55, overflow: 'auto', color: 'var(--ink-2)', margin: 0, maxHeight: '60vh' }}>
      {text}
    </pre>
  );
}

function DownloadIcon() {
  return <svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.2"><path d="M6 1v8M2.5 5.5L6 9l3.5-3.5M2 11h8" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}
function ShareIcon() {
  return <svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.2"><circle cx="3" cy="6" r="1.5" /><circle cx="9" cy="3" r="1.5" /><circle cx="9" cy="9" r="1.5" /><path d="M4.3 5.3l3.4-1.6M4.3 6.7l3.4 1.6" strokeLinecap="round" /></svg>;
}
function InfoIcon() {
  return <svg width="13" height="13" viewBox="0 0 14 14" fill="none" stroke="var(--accent)" strokeWidth="1.2"><circle cx="7" cy="7" r="6" /><path d="M7 6v4M7 4v.5" strokeLinecap="round" /></svg>;
}

// ─────────────────────────────────────────────────────────────────────────────
// Empty state
// ─────────────────────────────────────────────────────────────────────────────

function EmptyResults() {
  return (
    <div style={{ padding: '24px 28px', display: 'flex', flexDirection: 'column', gap: 22, maxHeight: 'calc(100vh - 64px)', overflow: 'auto' }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <h2 style={{ fontSize: 14, fontWeight: 600, margin: 0, letterSpacing: '-0.01em' }}>Sheet</h2>
          <span className="label-mono">empty</span>
        </div>
      </div>

      <div style={{ border: '1px dashed var(--border)', borderRadius: 4, padding: '60px 28px', textAlign: 'center', position: 'relative', minHeight: 420 }}>
        <div style={{ display: 'inline-flex', gap: 8, marginBottom: 22 }}>
          {[0, 1, 2].map((i) => (
            <div key={i} style={{
              width: 64, height: 64,
              border: '1px solid var(--border)',
              borderRadius: 3,
              background: i === 1 ? 'var(--surface-2)' : 'var(--surface)',
              position: 'relative',
              opacity: 1 - i * 0.25,
            }}>
              <span className="mono" style={{ position: 'absolute', top: 4, left: 6, fontSize: 9, color: 'var(--ink-4)' }}>0{i + 1}</span>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 6 }}>No sweep running</div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-3)', maxWidth: 360, margin: '0 auto', lineHeight: 1.5 }}>
          Configure your inputs, mark one or more as <span style={{ color: 'var(--accent)' }}>sweep</span>, then press <span className="mono" style={{ color: 'var(--ink-2)' }}>Run sweep</span> to fan out a matrix of generations.
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: 28, marginTop: 36, flexWrap: 'wrap' }}>
          <Hint k="↵" label="Run sweep" />
          <Hint k="⌘ ↵" label="Run + clear" />
          <Hint k="⌘ K" label="Switch model" />
          <Hint k="?" label="Help" />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start', padding: 16, border: '1px solid var(--border)', borderRadius: 4, background: 'var(--surface)' }}>
        <div style={{ flexShrink: 0, marginTop: 1 }}><InfoIcon /></div>
        <div>
          <div style={{ fontSize: 12.5, fontWeight: 500, marginBottom: 4 }}>What is a sweep?</div>
          <p style={{ fontSize: 12, color: 'var(--ink-3)', margin: 0, lineHeight: 1.6 }}>
            A sweep runs the same model across a grid of parameter combinations, so you can compare how each axis — seed, guidance, prompt — bends the output. Cells are capped at 9 to keep cost predictable.
          </p>
        </div>
      </div>
    </div>
  );
}

function Hint({ k, label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
      <kbd className="mono" style={{ border: '1px solid var(--border)', background: 'var(--surface)', borderRadius: 3, padding: '3px 7px', fontSize: 10.5, color: 'var(--ink-2)' }}>{k}</kbd>
      <span style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>{label}</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
